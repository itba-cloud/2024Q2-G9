def lambda_handler(event: dict, context: LambdaContext):
    return "Hello World"